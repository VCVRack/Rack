Instructions as of 2017/12/11
=============================

For licensing reasons, you need to download the vst sdk from [steinberg](https://www.steinberg.net/en/company/developers.html) (3.6.8 as of 2018/01/01)

Unpack and copy the 2 files located under `VST2_SDK/pluginterfaces/vst2.x` named aeffect.h and aeffectx.h to this folder
